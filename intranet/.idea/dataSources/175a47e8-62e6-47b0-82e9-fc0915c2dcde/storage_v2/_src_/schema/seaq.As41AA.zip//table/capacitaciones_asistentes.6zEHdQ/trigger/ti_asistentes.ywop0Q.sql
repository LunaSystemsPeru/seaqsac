create trigger ti_asistentes
  after INSERT
  on capacitaciones_asistentes
  for each row
BEGIN

declare _idcapacitacion int;

set _idcapacitacion = new.id_capacitaciones;

UPDATE capacitaciones 
set tot_asistentes = tot_asistentes + 1 
where id_capacitaciones = _idcapacitacion;

end;

